import joblib
import pandas as pd
import numpy as np

def custom_features(X):
    # If X is a numpy array (as returned by SimpleImputer), convert to DataFrame or use indices
    if isinstance(X, pd.DataFrame):
        X_out = X.copy()
        X_out['rooms_per_household'] = X_out['AveRooms'] / X_out['AveOccup']
        return X_out
    else:
        # Assuming order: MedInc, HouseAge, AveRooms, AveBedrms, Population, AveOccup
        # AveRooms is index 2, AveOccup is index 5
        rooms_per_household = X[:, 2] / X[:, 5]
        return np.column_stack([X, rooms_per_household])

def test_pipeline():
    try:
        # 1. Charger le pipeline
        pipeline = joblib.load("pipeline_california.pkl")
        print("✅ Pipeline chargé avec succès.")

        # 2. Créer un échantillon de test (simulant des données brutes avec manquants)
        # Ordre attendu par le pipeline : MedInc, HouseAge, AveRooms, AveBedrms, Population, AveOccup
        test_data = pd.DataFrame({
            'MedInc': [5.0, 2.0],
            'HouseAge': [15, 30],
            'AveRooms': [6.0, np.nan], # Un manquant pour tester l'imputation
            'AveBedrms': [1.0, 1.1],
            'Population': [800, 1200],
            'AveOccup': [3.0, 2.5]
        })

        print("\n--- Données de test (brutes) ---")
        print(test_data)

        # 3. Appliquer le pipeline
        transformed_data = pipeline.transform(test_data)

        print("\n--- Données transformées (après pipeline) ---")
        # Le résultat aura une colonne supplémentaire (rooms_per_household)
        cols = ['MedInc', 'HouseAge', 'AveRooms', 'AveBedrms', 'Population', 'AveOccup', 'rooms_per_household']
        result_df = pd.DataFrame(transformed_data, columns=cols)
        print(result_df)

        print("\n✅ Le pipeline fonctionne parfaitement !")

    except Exception as e:
        print(f"❌ Erreur lors du test : {e}")

if __name__ == "__main__":
    test_pipeline()
