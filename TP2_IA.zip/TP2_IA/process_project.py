import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import MinMaxScaler, StandardScaler, LabelEncoder, FunctionTransformer
from sklearn.impute import SimpleImputer
from sklearn.pipeline import Pipeline
from sklearn.compose import ColumnTransformer
import joblib
import os

# Create figures directory if it doesn't exist
os.makedirs("figures", exist_ok=True)

# 1. Charger le CSV
df = pd.read_csv("california_housing_biased.csv")
original_df = df.copy() # For comparison later

# 4.1 Limiter les données
# Supprimer Latitude et Longitude
df.drop(['Latitude', 'Longitude'], axis=1, inplace=True)
# Supprimer les colonnes inutiles (id, commentaire)
df.drop(['id', 'commentaire'], axis=1, inplace=True)
# Supprimer les enregistrements où MedHouseVal est nul ou négatif
df = df[df['MedHouseVal'] > 0]
# Supprimer les doublons
df.drop_duplicates(inplace=True)

# 4.2 Traiter les données manquantes
# Identifier les colonnes avec manquants
missing_info = df.isnull().mean() * 100
print("Proportion de valeurs manquantes :\n", missing_info)

# Imputation par la médiane
cols_to_impute = ['AveRooms', 'AveBedrms', 'Population', 'AveOccup']
for col in cols_to_impute:
    df[col] = df[col].fillna(df[col].median())

# Corriger les incohérences : AveBedrms > AveRooms
# Justification : Il est physiquement impossible d'avoir plus de chambres que de pièces totales. 
# On inverse les valeurs car il s'agit probablement d'une erreur de saisie.
mask = df['AveBedrms'] > df['AveRooms']
df.loc[mask, ['AveRooms', 'AveBedrms']] = df.loc[mask, ['AveBedrms', 'AveRooms']].values

# 4.3 Préparer les attributs numériques
# Validation sémantique : AveRooms et AveBedrms > 0
for col in ['AveRooms', 'AveBedrms']:
    mask = df[col] <= 0
    df.loc[mask, col] = df[col].median()

# Validation statistique : Outliers sur MedInc avec IQR
Q1 = df['MedInc'].quantile(0.25)
Q3 = df['MedInc'].quantile(0.75)
IQR = Q3 - Q1
lower_bound = Q1 - 1.5 * IQR
upper_bound = Q3 + 1.5 * IQR
outliers = df[(df['MedInc'] < lower_bound) | (df['MedInc'] > upper_bound)]
print(f"Nombre d'outliers MedInc : {len(outliers)}")

# Feature engineering
df['rooms_per_household'] = df['AveRooms'] / df['AveOccup']

# Discrétisation de MedInc
# 1. Intervalles égaux
df['MedInc_Equal'] = pd.cut(df['MedInc'], bins=[0, 3, 6, np.inf], labels=['low', 'medium', 'high'])
# 2. Quantiles
df['MedInc_Quantile'] = pd.qcut(df['MedInc'], q=3, labels=['low', 'medium', 'high'])
# 3. Répartition manuelle (similaire à Equal ici pour l'exemple)
df['IncomeCategory'] = df['MedInc_Equal']

# Normalisation
med_inc_original = df['MedInc'].copy()
scaler_minmax = MinMaxScaler()
scaler_std = StandardScaler()
df['MedInc_MinMax'] = scaler_minmax.fit_transform(df[['MedInc']])
df['MedInc_Std'] = scaler_std.fit_transform(df[['MedInc']])

# 4.4 Préparer les variables catégorielles
# IncomeCategory est déjà low, medium, high
# Quantification
le = LabelEncoder()
df['IncomeCategory_Code'] = le.fit_transform(df['IncomeCategory'])

# 4.5 Agrégation et Visualisations
# Comparer moyennes
comparison = pd.concat([original_df.mean(numeric_only=True), df.mean(numeric_only=True)], axis=1)
comparison.columns = ['Original', 'Cleaned']
print("Comparaison des moyennes :\n", comparison)

# Pivot table HouseAge vs IncomeCategory
df['HouseAge_Bin'] = pd.cut(df['HouseAge'], bins=[0, 20, 40, 60, 100], labels=['0-20', '20-40', '40-60', '60+'])
pivot_age = df.pivot_table(index='HouseAge_Bin', columns='IncomeCategory', values='MedHouseVal', aggfunc='mean')

# Density vs Price
df['density'] = df['Population'] / df['AveOccup']
df['density_category'] = pd.qcut(df['density'], q=3, labels=['faible', 'moyenne', 'forte'])
pivot_density = df.pivot_table(index='density_category', columns='IncomeCategory', values='MedHouseVal', aggfunc='mean')

# --- Graphiques ---
# 1. Histogramme MedInc before/after normalization
plt.figure(figsize=(12, 5))
plt.subplot(1, 2, 1)
sns.histplot(med_inc_original, kde=True, color='blue')
plt.title('MedInc Original')
plt.subplot(1, 2, 2)
sns.histplot(df['MedInc_Std'], kde=True, color='green')
plt.title('MedInc Standardized')
plt.tight_layout()
plt.savefig("figures/medinc_normalization.png")

# 2. Scatter MedInc vs MedHouseVal + regression
plt.figure(figsize=(10, 6))
sns.scatterplot(x='MedInc', y='MedHouseVal', data=df, alpha=0.5)
m, b = np.polyfit(df['MedInc'], df['MedHouseVal'], 1)
plt.plot(df['MedInc'], m*df['MedInc'] + b, color='red', label=f'y={m:.2f}x+{b:.2f}')
plt.title('MedInc vs MedHouseVal')
plt.legend()
plt.savefig("figures/scatter_reg.png")

# 3. Heatmap corrélation
plt.figure(figsize=(12, 10))
numeric_cols = df.select_dtypes(include=[np.number]).columns
sns.heatmap(df[numeric_cols].corr(), annot=True, cmap='coolwarm', fmt=".2f")
plt.title('Matrice de corrélation')
plt.savefig("figures/correlation_heatmap.png")

# 4. Pie chart IncomeCategory
plt.figure(figsize=(8, 8))
df['IncomeCategory'].value_counts().plot.pie(autopct='%1.1f%%', startangle=90, colors=['#ff9999','#66b3ff','#99ff99'])
plt.title('Répartition par catégorie de revenu')
plt.ylabel('')
plt.savefig("figures/income_pie.png")

# 5. Boxplot MedHouseVal by IncomeCategory
plt.figure(figsize=(10, 6))
sns.boxplot(x='IncomeCategory', y='MedHouseVal', data=df)
plt.title('Prix des maisons par catégorie de revenu')
plt.savefig("figures/boxplot_income.png")

# 4.6 Automatiser la préparation (Pipeline)
def custom_features(X):
    # If X is a numpy array (as returned by SimpleImputer), convert to DataFrame or use indices
    if isinstance(X, pd.DataFrame):
        X_out = X.copy()
        X_out['rooms_per_household'] = X_out['AveRooms'] / X_out['AveOccup']
        return X_out
    else:
        # Assuming order: MedInc, HouseAge, AveRooms, AveBedrms, Population, AveOccup
        # AveRooms is index 2, AveOccup is index 5
        rooms_per_household = X[:, 2] / X[:, 5]
        return np.column_stack([X, rooms_per_household])

# Full Pipeline
pipeline = Pipeline([
    ('imputer', SimpleImputer(strategy='median')),
    ('feature_gen', FunctionTransformer(custom_features)),
    ('scaler', MinMaxScaler())
])

# Fit on relevant columns
num_cols = ['MedInc', 'HouseAge', 'AveRooms', 'AveBedrms', 'Population', 'AveOccup']
pipeline.fit(df[num_cols])
joblib.dump(pipeline, "pipeline_california.pkl")

print("Tout a été généré avec succès.")
